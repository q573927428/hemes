# solidity-baby-steps
Contract examples for Ethereum

Edit: 2019/Jan/14 - This repo is from 2015... very early in the life of Ethereum/Solidity. It may be outdated. It's probably still useful as a general guide, but I'd check for syntax/operation improvements that may have come in the intervening 3-4 years.
